<?php
require "db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $message = trim($_POST["message"] ?? "");

    if ($message !== "" && strlen($message) <= 2000) {
        $stmt = $conn->prepare(
            "INSERT INTO messages (message) VALUES (?)"
        );
        $stmt->bind_param("s", $message);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: index.php");
    exit;
}

$result = $conn->query(
    "SELECT message, created_at
     FROM messages
     ORDER BY id DESC
     LIMIT 100"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Chat</title>
    <style>
        * { box-sizing: border-box; }
        :root { --ink: #172b3a; --muted: #718096; --accent: #0f9d82; --accent-dark: #087c67; }
        body {
            margin: 0;
            min-height: 100vh;
            padding: 42px 16px;
            background: linear-gradient(145deg, #edf7f5 0%, #f5f7fb 55%, #eaf0f8 100%);
            color: var(--ink);
            font-family: "Trebuchet MS", "Segoe UI", sans-serif;
            font-size: 15px;
        }
        .chat-container {
            max-width: 760px;
            margin: 0 auto;
            overflow: hidden;
            background: #fff;
            border: 1px solid #e2eceb;
            border-radius: 20px;
            box-shadow: 0 18px 45px rgba(28, 65, 77, .10);
        }
        .chat-header {
            padding: 27px 30px 24px;
            background: linear-gradient(120deg, #123d4a, #176b69);
            color: #fff;
        }
        h2 { margin: 0 0 7px; font-size: 28px; letter-spacing: -.5px; }
        .subtitle { margin: 0; color: #d4ece8; line-height: 1.5; }
        .chat-content { padding: 26px 30px 30px; }
        form { display: flex; gap: 10px; }
        input[type="text"] {
            flex: 1;
            min-width: 0;
            padding: 13px 15px;
            border: 1px solid #d6e2e1;
            border-radius: 10px;
            background: #fbfdfd;
            color: var(--ink);
            font: inherit;
            outline: none;
            transition: border-color .2s, box-shadow .2s, background .2s;
        }
        input[type="text"]:focus {
            background: #fff;
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(15, 157, 130, .12);
        }
        button {
            padding: 13px 22px;
            border: 0;
            border-radius: 10px;
            background: var(--accent);
            color: #fff;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
            transition: background .2s, transform .2s;
        }
        button:hover { background: var(--accent-dark); transform: translateY(-1px); }
        button:active { transform: translateY(0); }
        .section-heading { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin: 28px 0 15px; }
        h3 { margin: 0; color: #183e4a; font-size: 19px; }
        .message-count { padding: 5px 10px; border-radius: 20px; background: #e7f6f2; color: #087c67; font-size: 12px; font-weight: 700; }
        .message-list { display: grid; gap: 11px; }
        .message {
            padding: 15px 17px;
            background: #f7fbfa;
            border: 1px solid #e4efed;
            border-left: 3px solid #63c7b4;
            border-radius: 5px 12px 12px 5px;
            line-height: 1.55;
            overflow-wrap: anywhere;
            transition: background .2s, transform .2s;
        }
        .message:hover { background: #eff9f6; transform: translateX(2px); }
        .timestamp { display: inline-block; margin-top: 8px; color: var(--muted); font-size: 12px; }
        .empty-state { padding: 24px 16px; border: 1px dashed #cfdfdc; border-radius: 12px; color: var(--muted); text-align: center; background: #fbfdfd; }
        @media (max-width: 520px) {
            body { padding: 18px 10px; }
            .chat-header { padding: 23px 20px; }
            .chat-content { padding: 22px 18px 24px; }
            h2 { font-size: 24px; }
            form { flex-direction: column; }
            button { width: 100%; }
        }
    </style>
</head>
<body>
<div class="chat-container">
    <header class="chat-header">
        <h2>Simple Network Chat</h2>
        <p class="subtitle">A simple space to share thoughts with your network.</p>
    </header>

    <main class="chat-content">
        <form method="POST">
            <input type="text" name="message"
                   placeholder="Write a message..."
                   maxlength="2000" aria-label="Message" required>
            <button type="submit">Send message &rarr;</button>
        </form>

        <?php
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        ?>

        <div class="section-heading">
            <h3>Recent messages</h3>
            <span class="message-count"><?= count($messages) ?> message<?= count($messages) === 1 ? '' : 's' ?></span>
        </div>

        <div class="message-list">
        <?php if (empty($messages)): ?>
            <div class="empty-state">No messages yet. Start the conversation!</div>
        <?php else: ?>
            <?php foreach (array_reverse($messages) as $row): ?>
                <div class="message">
                    <?= htmlspecialchars($row["message"], ENT_QUOTES, "UTF-8") ?>
                    <br>
                    <small class="timestamp">
                        <?= htmlspecialchars($row["created_at"], ENT_QUOTES, "UTF-8") ?>
                    </small>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>